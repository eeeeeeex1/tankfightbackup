System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/lenovo/Desktop/tank7.6.17/assets/text/enemytank/enemytank.ts at runtime.
      throw new Error(`SyntaxError: D:\cocos\CocosDashboard\file:\C:\Users\lenovo\Desktop\tank7.6.17\assets\text\enemytank\enemytank.ts: Identifier 'ccclass' has already been declared. (21:8)

  19 | //import { Bullet } from './Bullet'; // 假设 Bullet 脚本的文件路径和类名为 Bullet
  20 |
> 21 | const { ccclass, property } = _decorator;
     |         ^
  22 |
  23 |
  24 | // 定义方向向量`);
    }
  };
});
//# sourceMappingURL=2c4013264e09014df6fb202a7ad271245630dace.js.map