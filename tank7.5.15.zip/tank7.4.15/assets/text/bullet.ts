import { _decorator, Component, Node, CircleCollider2D, ICollisionEvent } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('bullet')
export class bullet extends Component {
    private circleCollider: CircleCollider2D = null;

    start() {
        console.log("Bullet entity created.");

        this.circleCollider = this.node.getComponent(CircleCollider2D);
        if (!this.circleCollider) {
            console.error("CircleCollider2D not found on bullet.");
            return;
        }

        console.log("CircleCollider2D found and initialized.");

        // Try registering "collision-enter" event
        this.node.on(Node.EventType.COLLISION_ENTER, this.onCollisionEnter, this);
    }
   

    onCollisionEnter (other, self) {
        console.log('Collision occurred.');
        console.log('Collision details:', other, self);

        // 假设与坦克发生了碰撞
        if (other.node.name === 'tank1') {
            this.node.destroy();
            other.node.destory();
        }
    }

    onDestroy() {
        if (this.circleCollider) {
            this.circleCollider.off("collision-enter", this.onCollisionEnter, this);
            console.log("Collision event listener removed.");
        }
    }
}
