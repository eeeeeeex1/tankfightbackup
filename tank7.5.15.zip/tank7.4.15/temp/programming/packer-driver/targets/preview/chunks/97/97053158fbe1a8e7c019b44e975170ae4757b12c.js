System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/lenovo/Desktop/tank7.3.1/assets/text/bullet.ts at runtime.
      throw new Error("SyntaxError: D:cocosCocosDashboard\file:C:UserslenovoDesktop\tank7.3.1assets\text\bullet.ts: Missing semicolon. (17:11)\n\n  15 |             collider.on(Contact2DType.POST_SOLVE, this.onPostSolve, this);\n  16 |         }\n> 17 |     start() {\n     |            ^\n  18 |         // \u5728\u7EC4\u4EF6\u5F00\u59CB\u65F6\u6267\u884C\u7684\u903B\u8F91\n  19 |     }\n  20 |");
    }
  };
});
//# sourceMappingURL=97053158fbe1a8e7c019b44e975170ae4757b12c.js.map