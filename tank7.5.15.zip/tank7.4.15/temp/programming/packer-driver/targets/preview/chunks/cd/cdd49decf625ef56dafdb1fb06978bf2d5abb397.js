System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/lenovo/Desktop/tank7.3.1/assets/text/bullet.ts at runtime.
      throw new Error("SyntaxError: D:cocosCocosDashboard\file:C:UserslenovoDesktop\tank7.3.1assets\text\bullet.ts: Unexpected token (32:5)\n\n  30 |             this.node.destroy();\n  31 |         }\n> 32 |     },\n     |      ^\n  33 |\n  34 |     onDestroy() {\n  35 |         if (this.circleCollider) {");
    }
  };
});
//# sourceMappingURL=cdd49decf625ef56dafdb1fb06978bf2d5abb397.js.map