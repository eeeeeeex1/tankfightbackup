System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/cocoscreater/NewProject_1/assets/text/firedirection.ts at runtime.
      throw new Error("SyntaxError: D:cocosCocosDashboard\file:C:cocoscreaterNewProject_1assets\text\firedirection.ts: Identifier 'speed' has already been declared. (41:14)\n\n  39 |         const rgd =bullet.getComponent(RigidBody2D);\n  40 |         const speed = new Vec2(this.direction.x * 400, this.direction.y * 400);\n> 41 |         const speed= this.direction.multiplyScalar(400);\n     |               ^\n  42 |         rgd.linearVelocity=speed;\n  43 |     }\n  44 | }");
    }
  };
});
//# sourceMappingURL=d9c99f4fd5a250c8692e3046df6118b23fe04bc4.js.map