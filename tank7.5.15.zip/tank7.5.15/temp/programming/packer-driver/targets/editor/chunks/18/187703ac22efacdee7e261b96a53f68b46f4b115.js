System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/lenovo/Desktop/tank7.4.15/assets/text/tank0.ts at runtime.
      throw new Error(`SyntaxError: D:\cocos\CocosDashboard\file:\C:\Users\lenovo\Desktop\tank7.4.15\assets\text\tank0.ts: Missing semicolon. (105:27)

  103 |
  104 |         velocity.
> 105 |         if (this.rigidBody) {
      |                            ^
  106 |             this.rigidBody.linearVelocity = velocity;
  107 |         }
  108 |     }`);
    }
  };
});
//# sourceMappingURL=187703ac22efacdee7e261b96a53f68b46f4b115.js.map