System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Collider2D, Contact2DType, _dec, _class, _crd, ccclass, Bullet;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Collider2D = _cc.Collider2D;
      Contact2DType = _cc.Contact2DType;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "f16fbCbkbRMAqazbkYPerZc", "bullet1", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Collider2D', 'Contact2DType']);

      ({
        ccclass
      } = _decorator);

      _export("Bullet", Bullet = (_dec = ccclass('Bullet1'), _dec(_class = class Bullet extends Component {
        start() {
          let collider = this.getComponent(Collider2D);

          if (collider) {
            collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
          }
        }

        onBeginContact(selfCollider, otherCollider) {
          console.log("tank01"); // 确保只处理一次销毁操作

          this.scheduleOnce(() => {
            if (!selfCollider.isValid) return; // 防止已销毁的对象再次操作

            selfCollider.node.destroy();

            if (otherCollider && otherCollider.node.name !== 'normalwall') {
              otherCollider.node.destroy();
            }
          }, 0.1); // 稍微增加延迟，确保事件处理完毕
        }

        onDestroy() {
          let collider = this.getComponent(Collider2D);

          if (collider) {
            collider.off(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
          }
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=22142e2d2100a6225924eb12df916e6386249c46.js.map