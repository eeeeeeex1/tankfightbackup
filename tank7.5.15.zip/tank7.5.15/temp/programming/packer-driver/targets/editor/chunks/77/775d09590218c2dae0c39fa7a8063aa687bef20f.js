System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/lenovo/Desktop/tank7.4.15/assets/text/objectaffect.ts at runtime.
      throw new Error(`SyntaxError: D:\cocos\CocosDashboard\file:\C:\Users\lenovo\Desktop\tank7.4.15\assets\text\objectaffect.ts: Unexpected token (6:8)

  4 | @ccclass('objectaffect')
  5 | export class objectaffect extends Component {
> 6 |     let collider = this.getComponent(Collider2D);
    |         ^
  7 |         if (collider) {
  8 |             collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
  9 |         }`);
    }
  };
});
//# sourceMappingURL=775d09590218c2dae0c39fa7a8063aa687bef20f.js.map