System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Prefab, Input, input, RigidBody2D, instantiate, Vec2, _dec, _dec2, _class, _class2, _descriptor, _descriptor2, _crd, ccclass, property, firedirection1;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Prefab = _cc.Prefab;
      Input = _cc.Input;
      input = _cc.input;
      RigidBody2D = _cc.RigidBody2D;
      instantiate = _cc.instantiate;
      Vec2 = _cc.Vec2;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "acf90eXqSlNPYkgPRnPPj/i", "firedirection1", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Prefab', 'systemEvent', 'Input', 'input', 'EventMouse', 'SystemEvent', 'Node', 'EventKeyboard', 'macro', 'RigidBody2D', 'Vec3', 'instantiate']);

      __checkObsolete__(['Vec2']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("firedirection1", firedirection1 = (_dec = ccclass('firedirection1'), _dec2 = property(Prefab), _dec(_class = (_class2 = class firedirection1 extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "shootPower", _descriptor, this);

          //子弹的发射速度
          _initializerDefineProperty(this, "bulletPrefab", _descriptor2, this);

          this.direction = new Vec2(0, 0);
          this.lastFireTime = 0;
          // 上次发射时间
          this.fireInterval = 1;
        }

        // 发射间隔时间，单位秒
        start() {
          input.on(Input.EventType.KEY_DOWN, this.onKeyDown, this);
          input.on(Input.EventType.KEY_DOWN, this.keytodirection, this); //input.on(Input.EventType.KEY_UP,this.directiontokey,this);
        }

        onDestroy() {
          input.off(Input.EventType.KEY_DOWN, this.onKeyDown, this);
          input.off(Input.EventType.KEY_DOWN, this.keytodirection, this); //input.off(Input.EventType.KEY_UP,this.directiontokey,this);
        } //检测是否设计m按下 触发fireBullet


        onKeyDown(event) {
          if (event.keyCode === 77) {
            // console.log("鼠标左键已经按下");
            const now = Date.now();

            if (now - this.lastFireTime > this.fireInterval * 1000) {
              this.fireBullet();
              this.lastFireTime = now;
            }
          }
        }

        fireBullet() {
          const bullet = instantiate(this.bulletPrefab);
          bullet.setParent(this.node);
          bullet.setPosition(this.node.position); //设置子弹实例的具体属性

          const rgd = bullet.getComponent(RigidBody2D);
          const speed = new Vec2(this.direction.x * 400, this.direction.y * 400);
          rgd.linearVelocity = speed;
        }

        keytodirection(event) {
          switch (event.keyCode) {
            case 37:
              this.direction.y = 0;
              this.direction.x = -1;
              break;

            case 39:
              this.direction.y = 0;
              this.direction.x = 1;
              break;

            case 38:
              // console.log("按下了38 上")
              this.direction.x = 0;
              this.direction.y = 1;
              break;

            case 40:
              this.direction.x = 0;
              this.direction.y = -1;
              break;

            case 38 && 37:
              // console.log("按下了38 37 左上")
              this.direction.set(-1, 1);
              break;

            case 38 && 39:
              this.direction.set(1, 1);
              break;

            case 40 && 37:
              this.direction.set(-1, -1);
              break;

            case 40 && 39:
              this.direction.set(1, -1);
              break;
          }
        } //keyup删除方向

        /*
        private directiontokey(event:EventKeyboard){
            switch (event.keyCode) {
                case 37:
                case 39:
                    this.direction.x = 0;
                    break;
                case 38:
                case 40:
                    this.direction.y = 0;
                    break;
                  case 38 && 37:
                case 38 && 39:
                case 40 && 37:
                case 40 && 39:
                    this.direction.set(0, 0);
                    break;
                    
            }
        }
        */


      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "shootPower", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 500;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "bulletPrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=495537c7360a94a00fd046d5f2fa38daebb22eba.js.map