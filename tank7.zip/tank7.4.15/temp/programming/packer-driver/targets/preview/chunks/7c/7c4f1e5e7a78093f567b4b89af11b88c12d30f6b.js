System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/cocoscreater/NewProject_1/assets/text/background.ts at runtime.
      throw new Error("SyntaxError: D:cocosCocosDashboard\file:C:cocoscreaterNewProject_1assets\text\background.ts: Missing semicolon. (7:11)\n\n   5 | export class background extends Component {\n   6 |     start() {\n>  7 |         set fillColor (value) {\n     |            ^\n   8 |             if (!this.impl) {\n   9 |                 return;\n  10 |             }");
    }
  };
});
//# sourceMappingURL=7c4f1e5e7a78093f567b4b89af11b88c12d30f6b.js.map