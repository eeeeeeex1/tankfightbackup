System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Input, input, Node, macro, RigidBody2D, Vec3, instantiate, Vec2, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _descriptor3, _crd, ccclass, property, firedirection0;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Input = _cc.Input;
      input = _cc.input;
      Node = _cc.Node;
      macro = _cc.macro;
      RigidBody2D = _cc.RigidBody2D;
      Vec3 = _cc.Vec3;
      instantiate = _cc.instantiate;
      Vec2 = _cc.Vec2;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "03b5bcM+HRNr6OrX47NeHp/", "firedirection0", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Prefab', 'systemEvent', 'Input', 'input', 'EventMouse', 'SystemEvent', 'Node', 'EventKeyboard', 'macro', 'RigidBody2D', 'Vec3', 'instantiate']);

      __checkObsolete__(['Vec2']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("firedirection0", firedirection0 = (_dec = ccclass('firedirection0'), _dec2 = property(RigidBody2D), _dec3 = property(Node), _dec(_class = (_class2 = class firedirection0 extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "rigidBody", _descriptor, this);

          _initializerDefineProperty(this, "shootPower", _descriptor2, this);

          //子弹的发射速度
          _initializerDefineProperty(this, "bulletPrefab", _descriptor3, this);

          this.direction = new Vec3(0, 0, 0);
        }

        start() {
          input.on(Input.EventType.KEY_DOWN, this.onKeyDown, this);
          input.on(Input.EventType.KEY_DOWN, this.keytodirection, this); //input.on(Input.EventType.KEY_UP,this.directiontokey,this);
        }

        onDestroy() {
          input.off(Input.EventType.KEY_DOWN, this.onKeyDown, this);
          input.off(Input.EventType.KEY_DOWN, this.keytodirection, this); //input.off(Input.EventType.KEY_UP,this.directiontokey,this);
        } //检测是否设计鼠标左键按下 触发fireBullet


        onKeyDown(event) {
          if (event.keyCode === 74) {
            console.log("鼠标左键已经按下");
            this.fireBullet();
          }
        }

        fireBullet() {
          var bullet = instantiate(this.bulletPrefab);
          bullet.setParent(this.node);
          bullet.setPosition(this.node.position);
          var rgd = bullet.getComponent(RigidBody2D);
          var speed = new Vec2(this.direction.x * 400, this.direction.y * 400); //const speed= this.direction.multiplyScalar(400);

          rgd.linearVelocity = speed;
        }

        keytodirection(event) {
          switch (event.keyCode) {
            case macro.KEY.a:
              this.direction.y = 0;
              this.direction.x = -1;
              break;

            case macro.KEY.d:
              this.direction.y = 0;
              this.direction.x = 1;
              break;

            case macro.KEY.w:
              this.direction.x = 0;
              this.direction.y = 1;
              break;

            case macro.KEY.s:
              this.direction.x = 0;
              this.direction.y = -1;
              break;

            case macro.KEY.w && macro.KEY.a:
              this.direction.set(-1, 1);
              break;

            case macro.KEY.w && macro.KEY.d:
              this.direction.set(1, 1);
              break;

            case macro.KEY.s && macro.KEY.a:
              this.direction.set(-1, -1);
              break;

            case macro.KEY.s && macro.KEY.d:
              this.direction.set(1, -1);
              break;
          }
        }
        /*
        //keyup删除方向
        private directiontokey(event:EventKeyboard){
            switch (event.keyCode) {
                case macro.KEY.a:
                case macro.KEY.d:
                    this.direction.x = 0;
                    break;
                case macro.KEY.w:
                case macro.KEY.s:
                    this.direction.y = 0;
                    break;
                    
                case macro.KEY.w && macro.KEY.a:
                case macro.KEY.w && macro.KEY.d:
                case macro.KEY.s && macro.KEY.a:
                case macro.KEY.s && macro.KEY.d:
                    this.direction.set(0, 0);
                    break;
                    
            }
        }
        */


      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "rigidBody", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "shootPower", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 500;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "bulletPrefab", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=baa10ac90f44ee2a74c610eb10ad8fbc3ce4c68d.js.map