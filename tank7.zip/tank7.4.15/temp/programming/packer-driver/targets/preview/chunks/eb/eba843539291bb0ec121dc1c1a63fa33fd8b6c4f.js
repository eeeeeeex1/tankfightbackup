System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, CircleCollider2D, _dec, _class, _crd, ccclass, property, bullet;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      CircleCollider2D = _cc.CircleCollider2D;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "82eb8uL1E5A6qEHok/xv6Ww", "bullet", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'CircleCollider2D', 'ICollisionEvent']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("bullet", bullet = (_dec = ccclass('bullet'), _dec(_class = class bullet extends Component {
        constructor() {
          super(...arguments);
          this.circleCollider = null;
        }

        start() {
          console.log("Bullet entity created.");
          this.circleCollider = this.node.getComponent(CircleCollider2D);

          if (!this.circleCollider) {
            console.error("CircleCollider2D not found on bullet.");
            return;
          }

          console.log("CircleCollider2D found and initialized."); // Try registering "collision-enter" event

          this.node.on(Node.EventType.COLLISION_ENTER, this.onCollisionEnter, this);
        }

        onCollisionEnter(other, self) {
          console.log('Collision occurred.');
          console.log('Collision details:', other, self); // 假设与坦克发生了碰撞

          if (other.node.name === 'tank1') {
            this.node.destroy();
            other.node.destory();
          }
        }

        onDestroy() {
          if (this.circleCollider) {
            this.circleCollider.off("collision-enter", this.onCollisionEnter, this);
            console.log("Collision event listener removed.");
          }
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=eba843539291bb0ec121dc1c1a63fa33fd8b6c4f.js.map