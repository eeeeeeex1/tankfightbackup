System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/cocoscreater/NewProject_1/assets/text/tank1.ts at runtime.
      throw new Error("SyntaxError: D:cocosCocosDashboard\file:C:cocoscreaterNewProject_1assets\text\tank1.ts: Unexpected token (94:10)\n\n  92 |\n  93 |\n> 94 |     const ctx = this.node.getComponent(Graphics);\n     |           ^\n  95 |     // \u521B\u5EFA\u4E00\u4E2A cc.Color \u5BF9\u8C61\uFF0C\u5E76\u8BBE\u7F6E\u4E3A\u84DD\u8272\n  96 |     const blueColor = new Color().fromHEX('#AD4444');\n  97 |     // \u8BBE\u7F6E Graphics \u7EC4\u4EF6\u7684\u586B\u5145\u989C\u8272");
    }
  };
});
//# sourceMappingURL=34bb2e363851db4b1c618eb4baa36b516f893a8d.js.map