System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/lenovo/Desktop/tank7.4.15/assets/text/objectaffect.ts at runtime.
      throw new Error(`SyntaxError: D:\cocos\CocosDashboard\file:\C:\Users\lenovo\Desktop\tank7.4.15\assets\text\objectaffect.ts: Identifier 'PlayerController' has already been declared. (3:9)

  1 | import { _decorator, Component, Node, Collider2D,BoxCollider2D, Contact2DType,RigidBody2D} from 'cc';
  2 | import { PlayerController } from './tank0'; // 确保正确引入 PlayerController0 类
> 3 | import { PlayerController } from './tank1'; // 确保正确引入 PlayerController1 类
    |          ^
  4 | const { ccclass, property } = _decorator;
  5 |
  6 | @ccclass('objectaffect')`);
    }
  };
});
//# sourceMappingURL=1b4028d388e4d871d36c585e23033e69048cc82c.js.map