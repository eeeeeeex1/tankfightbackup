import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('normalwall')
export class wallbox extends Component {

    private key:number = 1;
    start() {

    }

    update(deltaTime: number) {
    }
}


