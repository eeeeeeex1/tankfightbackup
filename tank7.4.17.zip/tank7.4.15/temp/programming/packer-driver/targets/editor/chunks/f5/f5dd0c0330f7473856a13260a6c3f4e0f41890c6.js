System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/lenovo/Desktop/tank7.3.1/assets/text/bullet.ts at runtime.
      throw new Error(`SyntaxError: D:\cocos\CocosDashboard\file:\C:\Users\lenovo\Desktop\tank7.3.1\assets\text\bullet.ts: Unexpected token (33:5)

  31 |             this.node.destroy();
  32 |         }
> 33 |     },
     |      ^
  34 |
  35 |     onDestroy() {
  36 |         if (this.circleCollider) {`);
    }
  };
});
//# sourceMappingURL=f5dd0c0330f7473856a13260a6c3f4e0f41890c6.js.map