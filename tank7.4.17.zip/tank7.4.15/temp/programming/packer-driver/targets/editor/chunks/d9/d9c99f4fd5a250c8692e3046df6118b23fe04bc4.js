System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/cocoscreater/NewProject_1/assets/text/firedirection.ts at runtime.
      throw new Error(`SyntaxError: D:\cocos\CocosDashboard\file:\C:\cocoscreater\NewProject_1\assets\text\firedirection.ts: Identifier 'speed' has already been declared. (41:14)

  39 |         const rgd =bullet.getComponent(RigidBody2D);
  40 |         const speed = new Vec2(this.direction.x * 400, this.direction.y * 400);
> 41 |         const speed= this.direction.multiplyScalar(400);
     |               ^
  42 |         rgd.linearVelocity=speed;
  43 |     }
  44 | }`);
    }
  };
});
//# sourceMappingURL=d9c99f4fd5a250c8692e3046df6118b23fe04bc4.js.map