System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/lenovo/Desktop/tank7.3.1/assets/text/bullet.ts at runtime.
      throw new Error(`SyntaxError: D:\cocos\CocosDashboard\file:\C:\Users\lenovo\Desktop\tank7.3.1\assets\text\bullet.ts: Missing semicolon. (17:11)

  15 |             collider.on(Contact2DType.POST_SOLVE, this.onPostSolve, this);
  16 |         }
> 17 |     start() {
     |            ^
  18 |         // 在组件开始时执行的逻辑
  19 |     }
  20 |`);
    }
  };
});
//# sourceMappingURL=97053158fbe1a8e7c019b44e975170ae4757b12c.js.map