System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/cocoscreater/NewProject_1/assets/text/tank1.ts at runtime.
      throw new Error(`SyntaxError: D:\cocos\CocosDashboard\file:\C:\cocoscreater\NewProject_1\assets\text\tank1.ts: Unexpected token (94:10)

  92 |
  93 |
> 94 |     const ctx = this.node.getComponent(Graphics);
     |           ^
  95 |     // 创建一个 cc.Color 对象，并设置为蓝色
  96 |     const blueColor = new Color().fromHEX('#FCF2F2');
  97 |     // 设置 Graphics 组件的填充颜色`);
    }
  };
});
//# sourceMappingURL=d3135c8b2ad6d1dde9746d0999d16c2e664fe539.js.map