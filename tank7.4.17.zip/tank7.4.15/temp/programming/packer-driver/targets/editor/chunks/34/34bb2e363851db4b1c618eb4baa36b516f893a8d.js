System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/cocoscreater/NewProject_1/assets/text/tank1.ts at runtime.
      throw new Error(`SyntaxError: D:\cocos\CocosDashboard\file:\C:\cocoscreater\NewProject_1\assets\text\tank1.ts: Unexpected token (94:10)

  92 |
  93 |
> 94 |     const ctx = this.node.getComponent(Graphics);
     |           ^
  95 |     // 创建一个 cc.Color 对象，并设置为蓝色
  96 |     const blueColor = new Color().fromHEX('#AD4444');
  97 |     // 设置 Graphics 组件的填充颜色`);
    }
  };
});
//# sourceMappingURL=34bb2e363851db4b1c618eb4baa36b516f893a8d.js.map