System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/cocoscreater/NewProject_1/assets/text/background.ts at runtime.
      throw new Error(`SyntaxError: D:\cocos\CocosDashboard\file:\C:\cocoscreater\NewProject_1\assets\text\background.ts: Missing semicolon. (7:11)

   5 | export class background extends Component {
   6 |     start() {
>  7 |         set fillColor (value) {
     |            ^
   8 |             if (!this.impl) {
   9 |                 return;
  10 |             }`);
    }
  };
});
//# sourceMappingURL=7c4f1e5e7a78093f567b4b89af11b88c12d30f6b.js.map