System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/cocoscreater/NewProject_1/assets/text/tank0.ts at runtime.
      throw new Error("SyntaxError: D:cocosCocosDashboard\file:C:cocoscreaterNewProject_1assets\text\tank0.ts: Unexpected token (22:8)\n\n  20 |     }\n  21 |\n> 22 |     Vec2.UP=(0,1);\n     |         ^\n  23 |\n  24 |     private onKeyDown(event: EventKeyboard) {\n  25 |         switch (event.keyCode) {");
    }
  };
});
//# sourceMappingURL=05a027eb88fab1a4971ea0c1d8d6c0ae23987bb0.js.map