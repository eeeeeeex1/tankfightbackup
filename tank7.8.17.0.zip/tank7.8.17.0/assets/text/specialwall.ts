import { _decorator, Component, Node, Graphics, Color } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('specialwall')
export class background extends Component {
    private key:number = 0;
}
